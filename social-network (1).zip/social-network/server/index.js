"use strict";
var app = require("./app");
var port = 3800;

var mongoose = require("mongoose");
mongoose.Promise = global.Promise;

const dbUri =
  "mongodb+srv://harshad1610:BillMost56@ecommerce.cbbdi.mongodb.net/social-network?retryWrites=true&w=majority&appName=ecommerce";
const dbOptions = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
};

mongoose
  .connect(dbUri, dbOptions)
  .then(() => {
    console.log("Database connected successfully");

    app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
  })
  .catch((err) => console.log(err));
